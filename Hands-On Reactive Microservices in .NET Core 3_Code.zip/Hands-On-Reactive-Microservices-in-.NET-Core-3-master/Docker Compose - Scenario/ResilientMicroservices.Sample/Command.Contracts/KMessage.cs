﻿namespace Common.Contracts
{
    public class KMessage
    {
        public string Name { get; set; }
        public string EventData { get; set; }
    }
}
