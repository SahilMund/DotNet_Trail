﻿namespace Common.Contracts.Events
{
    public interface IEvent { }
}
