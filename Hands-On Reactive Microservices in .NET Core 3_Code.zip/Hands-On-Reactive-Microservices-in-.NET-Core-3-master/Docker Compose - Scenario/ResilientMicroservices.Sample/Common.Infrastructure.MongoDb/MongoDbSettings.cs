﻿using System;

namespace Common.Infrastructure.MongoDb
{
    public class MongoDbSettings
    {
        public string ServerConnection { get; set; }
        public string Database { get; set; }
    }
}
